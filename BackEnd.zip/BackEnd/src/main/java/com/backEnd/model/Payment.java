package com.backEnd.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "payment")
public class Payment {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int payment_id;
	private String total;
	private String user_name;
	private String first_name;
	private String last_name;
	private String bank_type;
	private String card_type;
	private String cvc_number;
	private String card_number;
	
	
	
	public Payment() {
		super();
	}



	public Payment(int payment_id, String total, String user_name, String first_name, String last_name,
			String bank_type, String card_type, String cvc_number, String card_number) {
		super();
		this.payment_id = payment_id;
		this.total = total;
		this.user_name = user_name;
		this.first_name = first_name;
		this.last_name = last_name;
		this.bank_type = bank_type;
		this.card_type = card_type;
		this.cvc_number = cvc_number;
		this.card_number = card_number;
	}



	public int getPayment_id() {
		return payment_id;
	}



	public void setPayment_id(int payment_id) {
		this.payment_id = payment_id;
	}



	public String getTotal() {
		return total;
	}



	public void setTotal(String total) {
		this.total = total;
	}



	public String getUser_name() {
		return user_name;
	}



	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}



	public String getFirst_name() {
		return first_name;
	}



	public void setFirst_name(String first_name) {
		this.first_name = first_name;
	}



	public String getLast_name() {
		return last_name;
	}



	public void setLast_name(String last_name) {
		this.last_name = last_name;
	}



	public String getBank_type() {
		return bank_type;
	}



	public void setBank_type(String bank_type) {
		this.bank_type = bank_type;
	}



	public String getCard_type() {
		return card_type;
	}



	public void setCard_type(String card_type) {
		this.card_type = card_type;
	}



	public String getCvc_number() {
		return cvc_number;
	}



	public void setCvc_number(String cvc_number) {
		this.cvc_number = cvc_number;
	}



	public String getCard_number() {
		return card_number;
	}



	public void setCard_number(String card_number) {
		this.card_number = card_number;
	}
	
	
	
	

}
