package com.backEnd.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.backEnd.model.CheckedOrders;

@Repository
public interface CheckedOrdersRepository extends CrudRepository <CheckedOrders, Integer> {
	
	@Query("SELECT m FROM CheckedOrders m WHERE m.checked_id = :checked_id")
	public ArrayList<CheckedOrders> viewByCheckedOrdersId(@Param("checked_id") int checked_id);
	
	
	@Query("SELECT y FROM CheckedOrders y WHERE y.user_name = :user_name")
	public List<CheckedOrders> viewByUserId(@Param("user_name") String user_name);
	
	
	@Query("SELECT z FROM CheckedOrders z WHERE z.order_id = :order_id")
	public List<CheckedOrders> viewByCheckedOrderId(@Param("order_id") int order_id);
	

}