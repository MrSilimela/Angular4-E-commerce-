package com.backEnd.repository;

//import CartRepository used files
import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.backEnd.model.Cart;


@Repository
public interface CartRepository extends CrudRepository <Cart, Integer> {

	
	//@Query("SELECT l FROM Cart l WHERE l.cart_id = :cart_id")
	//public ArrayList<Cart> viewByUser_name(@Param("cart_id") int cart_id);
	
	
	
	@Query("SELECT x FROM Cart x WHERE x.user_name = :user_name")
	public List<Cart> viewByUserId(@Param("user_name") String user_name);


}
