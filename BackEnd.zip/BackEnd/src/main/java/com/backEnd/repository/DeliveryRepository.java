package com.backEnd.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.backEnd.model.Delivery;

@Repository
public interface DeliveryRepository extends CrudRepository <Delivery, Integer> {
	
	@Query("SELECT m FROM Delivery m WHERE m.delivery_id = :delivery_id")
	public ArrayList<Delivery> viewByOrdersId(@Param("delivery_id") int delivery_id);
	
	
	@Query("SELECT y FROM Delivery y WHERE y.user_name = :user_name")
	public List<Delivery> viewByUserId(@Param("user_name") String user_name);

}