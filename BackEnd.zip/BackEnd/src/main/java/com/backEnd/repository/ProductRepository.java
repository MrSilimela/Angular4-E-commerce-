package com.backEnd.repository;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.backEnd.model.Product;

@Repository
public interface ProductRepository extends CrudRepository <Product, Integer> {


	@Query("SELECT l FROM Product l WHERE l.product_id = :product_id")
	public ArrayList<Product> viewByProductId(@Param("product_id") int product_id);
	
	
	@Query("SELECT x FROM Product x WHERE x.category_id = :category_id")
	public ArrayList<Product> viewByCategoryId(@Param("category_id") int category_id);
	

}
