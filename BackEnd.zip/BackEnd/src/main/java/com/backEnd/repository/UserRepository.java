package com.backEnd.repository;

import java.util.ArrayList;

import org.springframework.data.repository.CrudRepository;

import com.backEnd.model.User;



public interface UserRepository extends CrudRepository<User, Long> {
	
	 public User getByUsername(String username);
	    public User getByUsernameAndPassword (String username, String password);
		
	

}