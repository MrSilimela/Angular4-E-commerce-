package com.backEnd.repository;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.backEnd.model.Orders;

@Repository
public interface OrdersRepository extends CrudRepository <Orders, Integer> {
	
	@Query("SELECT n FROM Orders n WHERE n.order_id = :order_id")
	public ArrayList<Orders> viewByOrdersId(@Param("order_id") int order_id);
	
	
	@Query("SELECT z FROM Orders z WHERE z.user_name = :user_name")
	public List<Orders> viewByUserId(@Param("user_name") String user_name);

}