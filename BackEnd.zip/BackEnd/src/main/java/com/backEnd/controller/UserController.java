package com.backEnd.controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.backEnd.model.User;
import com.backEnd.service.UserService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping(path = "/user/service")
public class UserController {
	
	   @Autowired
	    private UserService userService;

	   @CrossOrigin(origins = "*")
	    @RequestMapping(value = "/register", method = RequestMethod.POST)
	    public HashMap register(@RequestBody User user) {
	        HashMap map = userService.register(user);
	        return map;
	    }
	    
	   @CrossOrigin(origins = "*")
	    @RequestMapping(value = "/login", method = RequestMethod.POST)
	    public HashMap login(@RequestBody User user) {
	        HashMap map = userService.validateUser(user);
	        return map;
	    }
	    
	    @RequestMapping(value = "/send/all/user")
	    public List<User> customerData() {
	        List sendData = userService.getAllUsers();
	        return sendData;
	    }
	    
	   

}
