package com.backEnd.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.backEnd.model.Product;
import com.backEnd.service.ProductService;


@CrossOrigin(origins = "*")
@RestController
public class ProductController {
	
	Product product = new Product();
	
	@Autowired
	private ProductService productService;
	
	@CrossOrigin(origins = "*")
	@RequestMapping("/GetProducts")
	public List<Product> getAllproducts() 
	{
		
		return productService.getAllproducts();
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(method = RequestMethod.DELETE,value = "/DeleteProduct/{productID}")
	public void DeleteProduct(@PathVariable int productID)
	{
		productService.DeleteProduct(productID);

	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(method = RequestMethod.POST,value = "/SaveProduct")
	public void SaveProduct(@RequestBody Product Products)
	{
		productService.SaveProduct(Products);		

	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(method = RequestMethod.PUT,value = "/UpdateProduct/{id}")
	public void updateProduct(@RequestBody Product Products, @PathVariable int id)
	{
		
		productService.updateProduct(id, Products);
		
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/ProductCategory/{category_id}", method = RequestMethod.GET)
	@ResponseBody
	public List<Product> getAllProduct(@PathVariable(value = "category_id") int category_id)
	{
		List<Product> Product = productService.getProduct(category_id);
	 
	return Product;
	}


}
