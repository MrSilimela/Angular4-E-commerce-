package com.backEnd.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.backEnd.model.Delivery;
import com.backEnd.service.DeliveryService;

@CrossOrigin(origins = "*")
@RestController
public class DeliveryController {
	
	
	@Autowired
	private DeliveryService deliveryService;
	
	@CrossOrigin(origins = "*")
	@RequestMapping("/GetDeliveries")
	public List<Delivery> getAlldeliveries() 
	{
		
		return deliveryService.getAlldeliveries();
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(method = RequestMethod.DELETE,value = "/DeleteDelivery/{deliveryID}")
	public void DeleteDelivery(@PathVariable int deliveryID)
	{
		deliveryService.DeleteDelivery(deliveryID);

	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(method = RequestMethod.POST,value = "/SaveDelivery")
	public void SaveOrders(@RequestBody Delivery Delivery)
	{
		deliveryService.SaveDelivery(Delivery);		

	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(method = RequestMethod.PUT,value = "/UpdateDelivery/{id}")
	public void updatePayment(@RequestBody Delivery Delivery, @PathVariable int id)
	{
		
		deliveryService.updateDelivery(id, Delivery);
		
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/UserDelivery/{user_name}", method = RequestMethod.GET)
	@ResponseBody
	public List<Delivery> getAllDelivery(@PathVariable(value = "user_name") String user_name)
	{
		List<Delivery> Delivery = deliveryService.getDelivery(user_name);
	 
	return Delivery;
	}

}
