package com.backEnd.controller;


import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.backEnd.model.Cart;
import com.backEnd.repository.CartRepository;
import com.backEnd.service.CartService;



@RestController
public class CartController {

	@Autowired
	private CartService cartService;
	
	@CrossOrigin(origins = "*")
	@RequestMapping(method = RequestMethod.POST,value = "/SaveCart")
	public void SaveCart(@RequestBody Cart Carts)
	{
		cartService.SaveCart(Carts);		

	}
	@CrossOrigin(origins = "*")
	@RequestMapping(method = RequestMethod.DELETE,value = "/DeleteCart/{cartID}")	
	public void DeleteCart(@PathVariable int cartID)
	{
		cartService.DeleteCart(cartID);

	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(method = RequestMethod.PUT,value = "/UpdateCart/{cartID}")
	public void updateCart(@RequestBody Cart carts, @PathVariable int cartID)
	{
		
		cartService.updateCart(cartID, carts);
		
	}
	@CrossOrigin(origins = "*")
	@RequestMapping("/GetCarts")
	public List<Cart> getAllCarts() 
	{
		return cartService.getAllCarts();
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/viewCart/{user_name}", method = RequestMethod.GET)
	@ResponseBody
	public List<Cart> getAllCart(@PathVariable(value = "user_name") String user_name)
	{
		List<Cart> Cart = cartService.getCart(user_name);
	 
	return Cart;
	}
	
	
}
