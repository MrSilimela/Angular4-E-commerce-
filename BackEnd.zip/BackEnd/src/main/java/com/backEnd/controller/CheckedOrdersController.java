package com.backEnd.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.backEnd.model.CheckedOrders;
import com.backEnd.service.CheckedOrdersService;

@CrossOrigin(origins = "*")
@RestController
public class CheckedOrdersController {
	
	
	@Autowired
	private CheckedOrdersService checkedOrdersService;
	
	@CrossOrigin(origins = "*")
	@RequestMapping("/GetCheckedOrders")
	public List<CheckedOrders> getAlldcheckedOrders() 
	{
		
		return checkedOrdersService.getAllcheckedOrders();
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(method = RequestMethod.DELETE,value = "/DeleteCheckedOrders/{checkedID}")
	public void DeleteCheckedOrders(@PathVariable int checkedID)
	{
		checkedOrdersService.DeleteCheckedOrders(checkedID);

	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(method = RequestMethod.POST,value = "/SaveCheckedOrders")
	public void SaveCheckedOrders(@RequestBody CheckedOrders CheckedOrders)
	{
		checkedOrdersService.SaveCheckedOrders(CheckedOrders);		

	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(method = RequestMethod.PUT,value = "/UpdateCheckedOrders/{id}")
	public void updateCheckedOrders(@RequestBody CheckedOrders CheckedOrders, @PathVariable int id)
	{
		
		checkedOrdersService.updateCheckedOrders(id, CheckedOrders);
		
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/UserCheckedOrders/{user_name}", method = RequestMethod.GET)
	@ResponseBody
	public List<CheckedOrders> getAllCheckedOrders(@PathVariable(value = "user_name") String user_name)
	{
		List<CheckedOrders> CheckedOrders = checkedOrdersService.getCheckedOrders(user_name);
	 
	return CheckedOrders;
	}
	
	@CrossOrigin(origins = "*")
	@RequestMapping(value = "/CheckedOrder/{order_id}", method = RequestMethod.GET)
	@ResponseBody
	public List<CheckedOrders> getAllCheckedOrder(@PathVariable(value = "order_id") int order_id)
	{
		List<CheckedOrders> CheckedOrder = checkedOrdersService.getCheckedOrder(order_id);
	 
	return CheckedOrder;
	}
	
	

}
