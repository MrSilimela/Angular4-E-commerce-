package com.backEnd.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.backEnd.model.Orders;
import com.backEnd.repository.OrdersRepository;

@Service
public class OrdersService {
	
	@Autowired
	public OrdersRepository ordersRepository;
	
	public List<Orders> getAllorders()
	{
		
		List<Orders> orders = new ArrayList<>();
		ordersRepository.findAll()
		.forEach(orders::add);
		return orders;
		
	}
	
	
	public void DeleteOrders(int orderID) {
		
		
		ordersRepository.delete(orderID);
		
	}
	

	public void SaveProduct(Orders Orders) {
		
		
		ordersRepository.save(Orders);
		
	}
	
	public void updateOrders(int id, Orders Orders) {
		
		
		ordersRepository.save(Orders);
		
	}
	
	public List<Orders> getOrder(String user_name)
	{
		
		return ordersRepository.viewByUserId(user_name);
	}
	
public void SaveOrder(Orders Orders) {
		
		
		ordersRepository.save(Orders);
		
	}

public void updateOrder(int orderID, Orders Orders) 
{

	ordersRepository.save(Orders);
}

}
