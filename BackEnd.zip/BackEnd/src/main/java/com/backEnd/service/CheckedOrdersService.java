package com.backEnd.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.backEnd.model.CheckedOrders;
import com.backEnd.repository.CheckedOrdersRepository;

@Service
public class CheckedOrdersService {
	
	@Autowired
	public CheckedOrdersRepository checkedOrdersRepository;
	
	public List<CheckedOrders> getAllcheckedOrders()
	{
		
		List<CheckedOrders> checkedOrders = new ArrayList<>();
		checkedOrdersRepository.findAll()
		.forEach(checkedOrders::add);
		return checkedOrders;
		
	}
	
	
	public void DeleteCheckedOrders(int checkedOrdersID) {
		
		
		checkedOrdersRepository.delete(checkedOrdersID);
		
	}
	

	public void SaveCheckedOrders(CheckedOrders CheckedOrders) {
		
		
		checkedOrdersRepository.save(CheckedOrders);
		
	}
	
	public void updateCheckedOrders(int id, CheckedOrders CheckedOrders) {
		
		
		checkedOrdersRepository.save(CheckedOrders);
		
	}
	
	public List<CheckedOrders> getCheckedOrders(String user_name)
	{
		
		return checkedOrdersRepository.viewByUserId(user_name);
	}
	
	public List<CheckedOrders> getCheckedOrder(int order_id)
	{
		
		return checkedOrdersRepository.viewByCheckedOrderId(order_id);
	}
	

}
