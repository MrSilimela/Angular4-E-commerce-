package com.backEnd.service;

//import CartService used files
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.backEnd.model.Cart;
import com.backEnd.repository.CartRepository;

@Service
public class CartService {
	 
	@Autowired
	public CartRepository CartRepository;
	

	
	//Add Cart 
	public void SaveCart(Cart Carts) {
		
		
		CartRepository.save(Carts);
		
	}
	
	//Delete Cart using cart id 
	public void DeleteCart(int cartID) {
		
		
		CartRepository.delete(cartID);
		
	}
	
	//Update Cart using cart id 
	public void updateCart(int cartID, Cart Carts) 
	{

		CartRepository.save(Carts);
	}

	//gets All Carts 
	public List<Cart> getAllCarts()
	{
		
		List<Cart> Carts = new ArrayList<>();
		CartRepository.findAll()
		.forEach(Carts::add);
		return Carts;
		
	}
	
	//gets Cart using user id 	
	public List<Cart> getCart(String user_name)
	{
		
		return CartRepository.viewByUserId(user_name);
	}
	
}
