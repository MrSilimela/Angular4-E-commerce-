package com.backEnd.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.backEnd.model.User;
import com.backEnd.repository.UserRepository;


@Service
public class UserService {

    private String status;
    private String message;
    protected HashMap map = new HashMap();
    protected User customer;

    @Autowired
    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // use list to find check logins
    public List<User> getAllUsers() {
        List<User> user = new ArrayList<>();
        userRepository.findAll().forEach(user::add);    // adding records to list
        return user;
    }

    public HashMap validateUser(User user) {

        user = userRepository.getByUsernameAndPassword(user.getUsername(), user.getPassword());

        if (user.getUsername().equals(user.getUsername()) && user.getPassword().equals(user.getPassword())) {
            message = "Login Successful";
            status = "success";
            
        } else {
            message = "Login Unsuccessful";
            status = "fail";
        }

        // values for angualar
        map.put("status", status);
        map.put("message", message);
        return map;
    }

    // it is not save though - until I find a solution
    public HashMap register(User user) {

        customer = userRepository.getByUsername(user.getUsername());     // find by email

        if (customer == null) {
            userRepository.save(user);                  // use crud interface and save data in database
            message = "Thank You For Registering With Us";
            status = "success";
        } else {
            message = "Registration Failure";
            status = "fail";
        }

        // values for angualar
        map.put("status", status);
        map.put("message", message);
        return map;
    }
    

}

