package com.backEnd.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.backEnd.model.Delivery;
import com.backEnd.repository.DeliveryRepository;

@Service
public class DeliveryService {
	
	@Autowired
	public DeliveryRepository deliveryRepository;
	
	public List<Delivery> getAlldeliveries()
	{
		
		List<Delivery> deliveries = new ArrayList<>();
		deliveryRepository.findAll()
		.forEach(deliveries::add);
		return deliveries;
		
	}
	
	
	public void DeleteDelivery(int deliveryID) {
		
		
		deliveryRepository.delete(deliveryID);
		
	}
	

	public void SaveDelivery(Delivery Deliveries) {
		
		
		deliveryRepository.save(Deliveries);
		
	}
	
	public void updateDelivery(int id, Delivery Deliveries) {
		
		
		deliveryRepository.save(Deliveries);
		
	}
	
	public List<Delivery> getDelivery(String user_name)
	{
		
		return deliveryRepository.viewByUserId(user_name);
	}
	

}
