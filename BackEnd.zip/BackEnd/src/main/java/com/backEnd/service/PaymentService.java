package com.backEnd.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.backEnd.model.Payment;
import com.backEnd.repository.PaymentRepository;

@Service
public class PaymentService {
	
	@Autowired
	public PaymentRepository paymentRepository;
	
	public List<Payment> getAllpayments()
	{
		
		List<Payment> payments = new ArrayList<>();
		paymentRepository.findAll()
		.forEach(payments::add);
		return payments;
		
	}
	
	
	public void DeletePayment(int paymentID) {
		
		
		paymentRepository.delete(paymentID);
		
	}
	

	public void SaveProduct(Payment Payments) {
		
		
		paymentRepository.save(Payments);
		
	}
	
	public void updateProduct(int id, Payment Payments) {
		
		
		paymentRepository.save(Payments);
		
	}
	
	public List<Payment> getPayment(String user_name)
	{
		
		return paymentRepository.viewByUserId(user_name);
	}
	
public void SavePayment(Payment Payments) {
		
		
		paymentRepository.save(Payments);
		
	}

public void updatePayment(int paymentID, Payment Payments) 
{

	paymentRepository.save(Payments);
}

}
