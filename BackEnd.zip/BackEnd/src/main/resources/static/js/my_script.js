$(document).ready( function(){
	
	$("div"). each( function) {
		
		$(this).append("<img src='/main/resources/static/images/products/bevarages" +i+".jpg' width='79'' height='79' />");
		
	});
	
	
});




